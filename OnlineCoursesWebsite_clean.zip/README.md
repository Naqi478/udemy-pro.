# Online Courses Website
This is a simple online courses platform with lecture notes and video placeholders.